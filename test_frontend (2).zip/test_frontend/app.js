// IIV login test frontend — .pfx yuklab kirish (imzo/ISigner/E-IMZO yo'q).
// Oqim: /auth/init (pinfl) -> /auth/pfx (fayl+parol) -> yuz (WS) -> /auth/complete.

const state = {
  gateway: "https://pinchable-semitruthfully-delma.ngrok-free.dev",
  challengeId: null,
  faceTicket: null,
  faceWsUrl: null,
};

const $ = (id) => document.getElementById(id);
function setStatus(el, text, kind) { el.textContent = text; el.className = "status show " + (kind || "info"); }
function setStatusHTML(el, html, kind) { el.innerHTML = html; el.className = "status show " + (kind || "info"); }
function enableCard(id) { $(id).classList.remove("disabled"); }

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result.split(",")[1]); // dataURL prefiksini kesamiz
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

// =====================================================================
// QADAM 1: init (pinfl) + pfx (fayl+parol)
// =====================================================================
$("initBtn").addEventListener("click", async () => {
  state.gateway = $("gatewayUrl").value.trim().replace(/\/$/, "");
  const file = $("pfxFile").files[0];
  const password = $("pfxPassword").value;

  if (!file) return setStatus($("initStatus"), ".pfx kalit faylini tanlang.", "bad");
  if (!password) return setStatus($("initStatus"), "Kalit parolini kiriting.", "bad");

  $("initBtn").disabled = true;
  try {
    // Yagona qadam: .pfx+parol -> kalit ichidan foydalanuvchi aniqlanadi.
    setStatusHTML($("initStatus"), '<span class="spinner"></span> Kalit fayli tekshirilmoqda...', "info");
    const pfx_b64 = await fileToBase64(file);
    const resp = await fetch(`${state.gateway}/auth/pfx`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pfx_b64, password }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || resp.status);

    state.challengeId = data.challenge_id;
    state.faceTicket = data.face_ticket;
    state.faceWsUrl = data.face_ws_url;
    const who = data.identity ? (data.identity.full_name || "") : "";
    setStatus($("initStatus"),
      "✓ ERI kalit tasdiqlandi! " + (who ? "Xodim: " + who + ". " : "") +
      (data.has_face ? "Yuz tanish bosqichiga o'ting." : "⚠ Bu xodimda yuz ro'yxatdan o'tmagan!"),
      "ok");
    enableCard("faceCard");
  } catch (e) {
    setStatus($("initStatus"), "Xato: " + e.message, "bad");
    $("initBtn").disabled = false;
  }
});

// =====================================================================
// QADAM 2: Yuz tanish (kamera + WebSocket)
// =====================================================================
let stream = null, ws = null, sending = false;

$("faceBtn").addEventListener("click", async () => {
  try {
    setStatus($("faceStatus"), "Kamera yoqilmoqda...", "info");
    stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
    $("video").srcObject = stream;

    ws = new WebSocket(state.faceWsUrl);
    ws.onopen = () => {
      ws.send(JSON.stringify({ face_ticket: state.faceTicket }));
      setStatus($("faceStatus"), "Face serverga ulandi, freymlar yuborilmoqda...", "info");
    };
    ws.onmessage = (ev) => handleFaceMessage(JSON.parse(ev.data));
    ws.onerror = () => setStatus($("faceStatus"), "WebSocket xatosi.", "bad");
    ws.onclose = () => { sending = false; };
    $("faceBtn").disabled = true;
  } catch (e) {
    setStatus($("faceStatus"), "Kamera xatosi: " + e.message, "bad");
  }
});

function captureFrameB64() {
  const v = $("video");
  const c = document.createElement("canvas");
  c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext("2d").drawImage(v, 0, 0);
  return c.toDataURL("image/jpeg", 0.8).split(",")[1];
}

function startSending() {
  if (sending) return;
  sending = true;
  const loop = () => {
    if (!sending || !ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ frame: captureFrameB64() }));
    setTimeout(loop, 350);
  };
  loop();
}

function handleFaceMessage(msg) {
  switch (msg.status) {
    case "ready":
      $("facePrompt").textContent = msg.prompt || "Kameraga qarang";
      setStatus($("faceStatus"), "Tayyor. Freymlar yuborilmoqda...", "info");
      startSending();
      break;
    case "liveness":
      $("facePrompt").textContent = msg.prompt || "";
      break;
    case "no_face":
      $("facePrompt").textContent = "Yuz ko'rinmayapti";
      break;
    case "spoof":
      setStatus($("faceStatus"), "⚠ Spoof aniqlandi — jonli yuz kerak.", "bad");
      break;
    case "no_match":
      setStatus($("faceStatus"), `Mos kelmadi (score=${msg.score?.toFixed(3)}). Davom etmoqda...`, "info");
      break;
    case "match":
      sending = false;
      $("facePrompt").textContent = "✓ Yuz tasdiqlandi";
      setStatus($("faceStatus"), `✓ Match (score=${msg.score?.toFixed(3)}). Proof olindi.`, "ok");
      if (stream) stream.getTracks().forEach((t) => t.stop());
      if (ws) ws.close();
      complete(msg.face_proof);
      break;
    case "error":
      setStatus($("faceStatus"), "Xato: " + (msg.message || ""), "bad");
      break;
  }
}

// =====================================================================
// QADAM 3: /auth/complete -> JWT
// =====================================================================
async function complete(faceProof) {
  enableCard("doneCard");
  setStatus($("doneStatus"), "JWT so'ralmoqda (/auth/complete)...", "info");
  try {
    const resp = await fetch(`${state.gateway}/auth/complete`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ challenge_id: state.challengeId, face_proof: faceProof }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || resp.status);

    setStatus($("doneStatus"), "✓ Muvaffaqiyatli login! JWT olindi.", "ok");
    const out = $("tokenOut");
    out.style.display = "block";
    out.textContent = JSON.stringify(data, null, 2);
  } catch (e) {
    setStatus($("doneStatus"), "Xato: " + e.message, "bad");
  }
}
