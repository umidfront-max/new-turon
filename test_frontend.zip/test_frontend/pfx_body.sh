#!/usr/bin/env bash
# Postman uchun JSON tanasini tayyorlaydi.
#   ./pfx_body.sh kalit.pfx 'parol'          -> ekranga chiqaradi
#   ./pfx_body.sh kalit.pfx 'parol' | xclip -sel clip   -> to'g'ridan-to'g'ri nusxalaydi
set -euo pipefail
python3 -c "
import base64, json, sys
print(json.dumps({
    'pfx_b64': base64.b64encode(open(sys.argv[1], 'rb').read()).decode(),
    'password': sys.argv[2],
}))
" "$1" "$2"
