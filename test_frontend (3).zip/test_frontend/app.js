// IIV login test frontend — .pfx yuklab kirish (imzo/ISigner/E-IMZO yo'q).
// Oqim: /auth/init (pinfl) -> /auth/pfx (fayl+parol) -> yuz (WS) -> /auth/complete.

const state = {
  gateway: "",
  challengeId: null,
  faceTicket: null,
  faceTicketExpiresAt: null,
  faceWsUrl: null,
};

const $ = (id) => document.getElementById(id);
function setStatus(el, text, kind) { el.textContent = text; el.className = "status show " + (kind || "info"); }
function setStatusHTML(el, html, kind) { el.innerHTML = html; el.className = "status show " + (kind || "info"); }
function enableCard(id) { $(id).classList.remove("disabled"); }
function disableCard(id) { $(id).classList.add("disabled"); }

// `face_ticket` — gateway imzolagan qisqa muddatli JWT (~120s). Server
// javobida muddati alohida qaytmaydi, shuning uchun tokenning o'z `exp`
// da'vosidan o'qiymiz — imzoni tekshirmaymiz (bu server ishi), faqat
// muddatini bilish uchun.
function decodeJwtExpiry(token) {
  try {
    const payload = JSON.parse(atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
    return typeof payload.exp === "number" ? payload.exp * 1000 : null;
  } catch {
    return null;
  }
}

// Sahifaning o'zi ham, /auth/... so'rovlari ham endi bitta gateway (nginx,
// 8088/ngrok) orqasida — shu manzilning o'zi standart qiymat bo'lsin, har
// safar ngrok URL o'zgarganda bu faylni qo'lda tahrirlash shart bo'lmasin.
// Boshqa manzilga (masalan lokal to'g'ridan-to'g'ri auth_gateway:8080) test
// qilish kerak bo'lsa, "Gateway manzili" qatorini qo'lda o'zgartirish kifoya.
if (!$("gatewayUrl").value.trim()) {
  $("gatewayUrl").value = window.location.origin;
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result.split(",")[1]); // dataURL prefiksini kesamiz
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

// =====================================================================
// QADAM 1: init (pinfl) + pfx (fayl+parol)
// =====================================================================
$("initBtn").addEventListener("click", async () => {
  state.gateway = $("gatewayUrl").value.trim().replace(/\/$/, "");
  const file = $("pfxFile").files[0];
  const password = $("pfxPassword").value;

  if (!file) return setStatus($("initStatus"), ".pfx kalit faylini tanlang.", "bad");
  if (!password) return setStatus($("initStatus"), "Kalit parolini kiriting.", "bad");

  $("initBtn").disabled = true;
  try {
    // Yagona qadam: .pfx+parol -> kalit ichidan foydalanuvchi aniqlanadi.
    setStatusHTML($("initStatus"), '<span class="spinner"></span> Kalit fayli tekshirilmoqda...', "info");
    const pfx_b64 = await fileToBase64(file);
    const resp = await fetch(`${state.gateway}/auth/pfx`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pfx_b64, password }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || resp.status);

    state.challengeId = data.challenge_id;
    state.faceTicket = data.face_ticket;
    state.faceTicketExpiresAt = decodeJwtExpiry(data.face_ticket);
    state.faceWsUrl = data.face_ws_url;
    const who = data.identity ? (data.identity.full_name || "") : "";
    setStatus($("initStatus"),
      "✓ ERI kalit tasdiqlandi! " + (who ? "Xodim: " + who + ". " : "") +
      (data.has_face ? "Yuz tanish bosqichiga o'ting." : "⚠ Bu xodimda yuz ro'yxatdan o'tmagan!"),
      "ok");
    enableCard("faceCard");
    $("faceBtn").disabled = false;
  } catch (e) {
    setStatus($("initStatus"), "Xato: " + e.message, "bad");
  } finally {
    // Doim qayta yoqilgan qoladi: yuz bosqichi keyinroq (ticket eskirgach)
    // muvaffaqiyatsiz bo'lsa ham, foydalanuvchi sahifani qayta yuklamasdan
    // shu yerdan YANGI ticket olishi kerak.
    $("initBtn").disabled = false;
  }
});

// =====================================================================
// QADAM 2: Yuz tanish (kamera + WebSocket)
// =====================================================================
let stream = null, ws = null, sending = false;

// Kamera/socket'ni to'xtatib, yuz bosqichini boshlang'ich holatga qaytaradi.
// `backToStep1=true` bo'lsa (masalan, ticket eskirgan/yaroqsiz chiqsa),
// karta qayta qulflanadi — 1-qadam qaytadan bajarilmasa, xuddi shu eski
// ticket bilan qayta urinish ma'nosiz, chunki natija bir xil bo'ladi.
function resetFaceStep({ backToStep1 = false } = {}) {
  sending = false;
  if (stream) { stream.getTracks().forEach((t) => t.stop()); stream = null; }
  if (ws) { ws.onclose = null; ws.close(); ws = null; }
  if (backToStep1) {
    state.faceTicket = null;
    state.faceTicketExpiresAt = null;
    disableCard("faceCard");
  } else {
    $("faceBtn").disabled = false;
  }
}

$("faceBtn").addEventListener("click", async () => {
  if (!state.faceTicket || (state.faceTicketExpiresAt && Date.now() >= state.faceTicketExpiresAt)) {
    setStatus($("faceStatus"),
      "Ticket muddati tugagan — 1-qadamni qaytadan bajaring (yangi ticket oling).",
      "bad");
    resetFaceStep({ backToStep1: true });
    return;
  }

  try {
    setStatus($("faceStatus"), "Kamera yoqilmoqda...", "info");
    stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
    $("video").srcObject = stream;

    ws = new WebSocket(state.faceWsUrl);
    ws.onopen = () => {
      ws.send(JSON.stringify({ face_ticket: state.faceTicket }));
      setStatus($("faceStatus"), "Face serverga ulandi, freymlar yuborilmoqda...", "info");
    };
    ws.onmessage = (ev) => handleFaceMessage(JSON.parse(ev.data));
    ws.onerror = () => {
      setStatus($("faceStatus"), "WebSocket xatosi.", "bad");
      resetFaceStep();
    };
    ws.onclose = () => { sending = false; };
    $("faceBtn").disabled = true;
  } catch (e) {
    setStatus($("faceStatus"), "Kamera xatosi: " + e.message, "bad");
    resetFaceStep();
  }
});

function captureFrameB64() {
  const v = $("video");
  const c = document.createElement("canvas");
  c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext("2d").drawImage(v, 0, 0);
  return c.toDataURL("image/jpeg", 0.8).split(",")[1];
}

function startSending() {
  if (sending) return;
  sending = true;
  const loop = () => {
    if (!sending || !ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ frame: captureFrameB64() }));
    setTimeout(loop, 350);
  };
  loop();
}

function handleFaceMessage(msg) {
  switch (msg.status) {
    case "ready":
      $("facePrompt").textContent = msg.prompt || "Kameraga qarang";
      setStatus($("faceStatus"), "Tayyor. Freymlar yuborilmoqda...", "info");
      startSending();
      break;
    case "liveness":
      $("facePrompt").textContent = msg.prompt || "";
      break;
    case "no_face":
      $("facePrompt").textContent = "Yuz ko'rinmayapti";
      break;
    case "spoof":
      setStatus($("faceStatus"), "⚠ Spoof aniqlandi — jonli yuz kerak.", "bad");
      break;
    case "no_match":
      setStatus($("faceStatus"), `Mos kelmadi (score=${msg.score?.toFixed(3)}). Davom etmoqda...`, "info");
      break;
    case "match":
      sending = false;
      $("facePrompt").textContent = "✓ Yuz tasdiqlandi";
      setStatus($("faceStatus"), `✓ Match (score=${msg.score?.toFixed(3)}). Proof olindi.`, "ok");
      if (stream) stream.getTracks().forEach((t) => t.stop());
      if (ws) ws.close();
      complete(msg.face_proof);
      break;
    case "error": {
      // Server "face_ticket"ni rad etganda ham shu holat keladi (masalan,
      // muddati tugagan yoki boshqa sababdan yaroqsiz) — eski ticket bilan
      // qayta urinish bir xil xatoni takrorlaydi, shuning uchun 1-qadamga
      // qaytaramiz.
      const isTicketProblem = /ticket/i.test(msg.message || "");
      setStatus($("faceStatus"),
        "Xato: " + (msg.message || "") +
        (isTicketProblem ? " — 1-qadamni qaytadan bajaring." : ""),
        "bad");
      resetFaceStep({ backToStep1: isTicketProblem });
      break;
    }
  }
}

// =====================================================================
// QADAM 3: /auth/complete -> JWT
// =====================================================================
async function complete(faceProof) {
  enableCard("doneCard");
  setStatus($("doneStatus"), "JWT so'ralmoqda (/auth/complete)...", "info");
  try {
    const resp = await fetch(`${state.gateway}/auth/complete`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ challenge_id: state.challengeId, face_proof: faceProof }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || resp.status);

    setStatus($("doneStatus"), "✓ Muvaffaqiyatli login! JWT olindi.", "ok");
    const out = $("tokenOut");
    out.style.display = "block";
    out.textContent = JSON.stringify(data, null, 2);
  } catch (e) {
    setStatus($("doneStatus"), "Xato: " + e.message, "bad");
  }
}
